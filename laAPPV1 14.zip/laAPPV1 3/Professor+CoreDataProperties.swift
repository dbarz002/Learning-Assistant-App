//
//  Professor+CoreDataProperties.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/24/17.
//  Copyright © 2017 FIU. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Professor { //Create NSManagedObject Subclass…

    @NSManaged var classes: [String]
    @NSManaged var name: String?
    @NSManaged var pin: String?
    @NSManaged var laRel: NSSet?

}
