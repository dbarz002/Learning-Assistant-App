//
//  Appointment+CoreDataProperties.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/25/17.
//  Copyright © 2017 FIU. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Appointment { //Create NSManagedObject Subclass…

    @NSManaged var student: NSObject?
    @NSManaged var la: NSObject?
    @NSManaged var date: NSDate?
    @NSManaged var time: NSObject?
    @NSManaged var studentRel: NSSet?

}
