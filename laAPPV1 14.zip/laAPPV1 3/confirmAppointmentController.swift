//
//  confirmAppointmentController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/26/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit


class confirmAppointmenController:  UIViewController {
    
    @IBOutlet weak var AppointmentDay: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var laName: UILabel!
    var day : NSDate!
    var time : String!
    var nameLA: String!
    var learningAssistant : LA!
    var student : Student!
    let model = AppointmentModel.sharedInstance
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        let dateFormatter = NSDateFormatter() // formatter for date
        dateFormatter.dateFormat = "MM/dd/yy" // sets format wanted to be used
        let dateString = dateFormatter.stringFromDate(day) // gives string the formattted date turned into a string
        AppointmentDay.text = dateString // sets text with day of appointment
        timeLabel.text = time // sets text with day of appointment
        laName.text = nameLA // sets text with day of appointment
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
    }
    
    @IBAction func createAppointment (sender: AnyObject) {
        print(day)
        print(learningAssistant.name)
        print(time)
        print(student.name)
        model.createNewAppointment(day, aLA: learningAssistant.name!, aTime: time, aStudent: student.name!) // create new appointment
      
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
}