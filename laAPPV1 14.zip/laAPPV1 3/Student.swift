//
//  Student.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/25/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData


class Student: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
