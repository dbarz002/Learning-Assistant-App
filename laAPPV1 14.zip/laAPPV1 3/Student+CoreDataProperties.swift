//
//  Student+CoreDataProperties.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/25/17.
//  Copyright © 2017 FIU. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension Student { //Create NSManagedObject Subclass…

    @NSManaged var classes: NSObject?
    @NSManaged var email: String?
    @NSManaged var name: String?
    @NSManaged var phone: String?
    @NSManaged var pin: String?
    @NSManaged var appointment: NSSet?

}
