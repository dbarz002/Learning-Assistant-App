//
//  ProfessorModel.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/17/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import CoreData
import UIKit

   final class ProfessorModel  {
    
        static let sharedInstance = ProfessorModel()  // creates shared instance
        private var classes : [String] = ["COP4005", "MAD1100", "COP4605", "CTS4348", "COP2000"]
    
        private var classesToAdd : [String : Bool] = ["COP 4005": false, "MAD1100": false, "COP4605": false, "CTS4348": false, "COP2000": false]
        private var professors : [NSManagedObject] = []
        
        private init () {
            
         
        }
    
    
    
    func createNewProfessor (aName: String, aPin: String, classes: [String]){ // function to create a professor

        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // gets entity description and creates an NSManagedObject for us
        let newProfessor = NSEntityDescription.entityForName("Professor", inManagedObjectContext: managedContext)
        let professor = NSManagedObject(entity: newProfessor!, insertIntoManagedObjectContext: managedContext)
        
        
        // sets all values for the NSManagedObject
        professor.setValue(aName, forKey: "name")
        professor.setValue(aPin, forKey: "pin")
        professor.setValue(classes, forKey: "classes")
        
        do {
            try managedContext.save() // save context
            professors.append(professor)
        }
        catch {
            print("error")
        }
    }
    
    func fetchProfessor(pin: String) -> NSManagedObject {
        
        var professor: NSManagedObject!
        
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        //creates fetch request with predicate to filter out results
        let professorFetch = NSFetchRequest(entityName: "Professor")
        let pin = pin
        professorFetch.returnsObjectsAsFaults = false
        professorFetch.predicate = NSPredicate(format: "pin == %@", pin)
        
        do {
            let professorsFetched = try managedContext.executeFetchRequest(professorFetch) // executes request
            for prof in professorsFetched {
                professor = prof as! NSManagedObject // returns professor
            }
        }
            
        catch {
            print("error")
        }
        
        return professor

    }
    
    
    func fetchProfessorsName(pin: String) -> String {
        
        var name : String = ""
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        //creates fetch request with predicate to filter out results
        let professorFetch = NSFetchRequest(entityName: "Professor")
        let pin = pin
        professorFetch.returnsObjectsAsFaults = false
        professorFetch.predicate = NSPredicate(format: "pin == %@", pin)
        
        do {
            let professorsFetched = try managedContext.executeFetchRequest(professorFetch) // executes request
            professors = professorsFetched as! [NSManagedObject]
            for prof in professors {
                name = prof.valueForKey("name") as! String // returns professor name
            }
        }
            
        catch {
            print("error")
        }
        
        return name
    }
    

    func fetchProfessorsLearningAssistants(pin: String) -> [NSManagedObject] {
        
        var learningAssistants : [NSManagedObject]?
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        //creates fetch request with predicate to filter out results
        let professorFetch = NSFetchRequest(entityName: "Professor")
        let pin = pin
        professorFetch.returnsObjectsAsFaults = false
        professorFetch.predicate = NSPredicate(format: "pin == %@", pin)
        
        do {
            let professorsFetched = try managedContext.executeFetchRequest(professorFetch) // executes request
            print(professorsFetched)
            for prof in professorsFetched {
                let newProf = prof as! Professor
                for la in newProf.laRel?.allObjects as! [LA]{ // failed attempt at relationships
                    print(la)
                    learningAssistants?.append(la as NSManagedObject)
                }
            
            }
        }
            
        catch {
            print("error")
        }
        
        return learningAssistants!
    }
    
    func fetchProfessorsPin(pin: String) -> Bool {
        var flag = true
        
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        //creates fetch request with predicate to filter out results
        let professorFetch = NSFetchRequest(entityName: "Professor")
        professorFetch.returnsObjectsAsFaults = false
        let pinNumber = pin
        professorFetch.predicate = NSPredicate(format: "pin == %@", pinNumber)
        
        do {
            let professorsFetched = try managedContext.executeFetchRequest(professorFetch) // executes request
            professors = professorsFetched as! [NSManagedObject]
        }
            
        catch {
            print("error")
        }
        
        if professors.isEmpty {
            flag = false
        }
        
        return flag
    }
    
    func fetchProfessorsClasses(pin: String) -> [String] {
        var classesArray : [String] = []
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        //creates fetch request with predicate to filter out results
        let professorFetch = NSFetchRequest(entityName: "Professor")
        professorFetch.returnsObjectsAsFaults = false
        let pinNumber = pin
        professorFetch.predicate = NSPredicate(format: "pin == %@", pinNumber)
        
        do {
            let professorsFetched = try managedContext.executeFetchRequest(professorFetch) // executes request
            professors = professorsFetched as! [NSManagedObject]
            
            for prof in professors {
                let array = prof.valueForKey("classes") as! [String]
                for i in 0...array.count-1 {
                    classesArray.append(array[i]) //  gets all classes that professor teaches
                }
            }
            
        }
            
        catch {
            print("error")
        }
        
        return classesArray
    }
    
    
    
    func classesNumber() -> Int {
        return classes.count
    }
    
    func getClassInfo(index: Int) -> String {
        return classes[index]
    }
    
    func getTrueClasses() {
        for (String, Bool) in classesToAdd {
            if Bool == true {
                print(String)
            }
        }
        
    }
    
  
}
