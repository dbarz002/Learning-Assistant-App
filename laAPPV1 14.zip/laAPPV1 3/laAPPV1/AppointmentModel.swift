//
//  AppointmentModel.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/26/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit

final class AppointmentModel  {
    
    static let sharedInstance = AppointmentModel()  // creates shared instance
    private var classes : [String] = ["COP4005", "MAD1100", "COP4605", "CTS4348", "COP2000"]
    
    private var classesToAdd : [String : Bool] = ["COP 4005": false, "MAD1100": false, "COP4605": false, "CTS4348": false, "COP2000": false]
    
    
    private init () {
        
    }
    
    
    
    func createNewAppointment (aDate: NSDate, aLA: String, aTime: String, aStudent: String){
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // gets entity description and creates an NSManagedObject for us
        let newAppointment = NSEntityDescription.entityForName("Appointment", inManagedObjectContext: managedContext)
        let appointment = NSManagedObject(entity: newAppointment!, insertIntoManagedObjectContext: managedContext)
        
        // sets all values for the NSManagedObject
        appointment.setValue(aDate, forKey: "date")
        appointment.setValue(aLA, forKey: "la")
        appointment.setValue(aTime, forKey: "time")
        appointment.setValue(aStudent, forKey: "student")
        
        print(appointment)
        do {
            try managedContext.save() // save context
            
        }
        catch {
            print("error")
        }
    }
    
    
    func fetchAppointmentforStudent(student : Student) -> [Appointment] {
        var appoinmentsArray: [Appointment] = []
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // creates fetch request with predicate to filter out results
        let student : String = student.name!
        let appointmentFetch = NSFetchRequest(entityName: "Appointment")
        appointmentFetch.returnsObjectsAsFaults = false
        appointmentFetch.predicate = NSPredicate(format: "student == %@", student)
        
        do {
            let appointmentsFetched = try managedContext.executeFetchRequest(appointmentFetch) // executes request
            
            for appointment in appointmentsFetched {
                
                    appoinmentsArray.append(appointment as! Appointment) // gets all appointments for that student
                
                }
                
                
                
                
                
        }
        
            
        catch {
            print("error")
        }
        
        return appoinmentsArray

    }
}
