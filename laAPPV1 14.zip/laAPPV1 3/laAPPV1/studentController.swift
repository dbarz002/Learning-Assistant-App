//
//  studentController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/19/17.
//  Copyright © 2017 FIU. All rights reserved.
//


import Foundation
import CoreData
import UIKit

class studentController: UIViewController, UINavigationControllerDelegate {
    
    var name : String = ""
    let myModel = studentModel.sharedInstance
    @IBOutlet weak var nameLabel: UILabel!
    var student : Student!
    let appointmentModel = AppointmentModel.sharedInstance
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.delegate = self // delegate
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(animated: Bool) { // will appear method to display values in view controller
        super.viewWillAppear(animated)
        nameLabel.text = name // loads label with student logged in name
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        view.endEditing(true)
        
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // method to prepare for segue
        if segue.identifier == "createAppointment" {
            
            
            let detailViewController = segue.destinationViewController as! createAppointmentController
            detailViewController.student = student // passes student object
      
        }
        
        if segue.identifier == "manageAppointment" {
            
            
            let arrayAppointments : [Appointment]  = appointmentModel.fetchAppointmentforStudent(student)

            let detailViewController = segue.destinationViewController as! manageAppointmentController
            detailViewController.arrayAppointments = arrayAppointments // passes arrayof appointments
            
            
        }

       
    }
   
}