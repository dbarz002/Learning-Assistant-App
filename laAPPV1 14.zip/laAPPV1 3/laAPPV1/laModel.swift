//
//  laModel.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/19/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit

final class laModel  {
    
    static let sharedInstance = laModel() // creates shared instance
    private var classes : [String] = ["COP4005", "MAD1100", "COP4605", "CTS4348", "COP2000"]
    private var hoursAvailable : [String] = ["9AM", "10AM", "11AM", "12PM", "1PM", "2PM", "3PM", "4PM", "5PM", "6PM", "7PM","8PM", "9PM"]
    private var daysAvailable : [String] = ["Monday", "Tuesday", "Wednesday","Thursday", "Friday"]
    private var assistants : [NSManagedObject] = []
    
    private init () {
        
        
    }
    
    
    
    func createNewLearningAssistant (aName: String, classes: [String], hours: [String], days: [String], anEmail: String, aPhone: String){
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // gets entity description and creates an NSManagedObject for us
        let newLearningAssistant = NSEntityDescription.entityForName("LA", inManagedObjectContext: managedContext)
        let LearningAssistant = NSManagedObject(entity: newLearningAssistant! , insertIntoManagedObjectContext: managedContext)
        
         // sets all values for the NSManagedObject
        LearningAssistant.setValue(aName, forKey: "name")
        LearningAssistant.setValue(classes, forKey: "classes")
        LearningAssistant.setValue(aPhone, forKey: "phone")
        LearningAssistant.setValue(anEmail, forKey: "email")
        LearningAssistant.setValue(hours, forKey: "hours")
        LearningAssistant.setValue(days, forKey: "days")

        
        do {
            try managedContext.save() // save context
            assistants.append(LearningAssistant)
        }
        catch {
            print("error")
        }
    }
    
    func fetchlearningAssistantName(code: String) -> String {
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // creates fetch request with predicate to filter out results
        let laFetch = NSFetchRequest(entityName: "LA")
        laFetch.returnsObjectsAsFaults = false
        
        do {
            let lasFetched = try managedContext.executeFetchRequest(laFetch) // executes request
            
            assistants = lasFetched as! [NSManagedObject]
            
        }
            
        catch {
            print("error")
        }
        
        return assistants.description
    }
    
    func fetchlearningAssistantDay(day: String) -> [LA] {
        var laArray : [LA] = []
        var flag : Bool = false
        
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        let givenDay = day
        
        // creates fetch request
        let laFetch = NSFetchRequest(entityName: "LA")
        
        
        do {
            
            let lasFetched = try managedContext.executeFetchRequest(laFetch) // executes request
            
            for la in lasFetched {
                let usablela : LA = la as! LA
                let ladayArray : [String] = usablela.days
                flag = false
                for day in ladayArray {
                    // if the la is available for that given day the add to the [la] array to be returned
                    if day == givenDay && flag == false {
                        laArray.append(usablela)
                        flag = true
                    }

                }
            
             }
        }
        catch {
            print("error")
        }
        
        return laArray
    }
    
    
    
    
    func fetchAllLearningAssistants() -> [laModel]{
        var la = [laModel]()
        
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        let laFetch = NSFetchRequest(entityName: "LA")
        
        do {
            
        la = try managedContext.executeFetchRequest(laFetch) as! [laModel] // executes request
            
        }
        
        catch {
            print("error")
        }
        
        return la
    }
    
    
    
    func fetchNewLearningAssistant(phone: String) -> NSManagedObject {
        var assistant: NSManagedObject!
        
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // creates fetch request with predicate to filter out results
        let newLearningAssistantFetch = NSFetchRequest(entityName: "LA")
        let phone = phone
        newLearningAssistantFetch.predicate = NSPredicate(format: "phone == %@", phone)
        
        do {
            let newAssitantFetched = try managedContext.executeFetchRequest(newLearningAssistantFetch) // executes request
            for newAssistant in newAssitantFetched {
                assistant = newAssistant as! NSManagedObject // gets new learning assistant created
            }
        }
            
        catch {
            print("error")
        }
        
        return assistant
    }
    
    
    func fetchStudentClasses() -> String {
        
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // creates fetch request with predicate to filter out results
        let studentFetch = NSFetchRequest(entityName: "Professor")
        let name = "1234567"
        studentFetch.predicate = NSPredicate(format: "classes == %@", name)
        
        do {
            let studentsFetched = try managedContext.executeFetchRequest(studentFetch) // executes request
            assistants = studentsFetched as! [NSManagedObject]
            
        }
            
        catch {
            print("error")
        }
        
        return assistants.description
    }
    
    func classesNumber() -> Int {
        return classes.count
    }
    
    func daysNumber() -> Int {
        return daysAvailable.count
    }
    
    func timesNumber() -> Int {
        return hoursAvailable.count
    }
    
    func getClassInfo(index: Int) -> String {
        return classes[index]
    }
    
    func getTimesInfo(index: Int) -> String {
        return hoursAvailable[index]
    }
    
    func getDaysInfo(index: Int) -> String {
        return daysAvailable[index]
    }
    
    func deletesLA(index: Int) {
         classes.removeAtIndex(index)
    }
    
    
    
}
