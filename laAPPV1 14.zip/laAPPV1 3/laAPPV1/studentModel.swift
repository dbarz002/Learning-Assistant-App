//
//  studentModel.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/18/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit

final class studentModel  {
    
    static let sharedInstance = studentModel()  // creates shared instance
    private var classes : [String] = ["COP4005", "MAD1100", "COP4605", "CTS4348", "COP2000"]
    
    private var students : [NSManagedObject] = []
    //var name : String = ""
    private init () {
        
        
    }
    
    
    
    func createNewStudent (aName: String, aPin: String, classes: [String], anEmail: String, aPhone: String){ // function to create a student
        // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // gets entity description and creates an NSManagedObject for us
        let newStudent = NSEntityDescription.entityForName("Student", inManagedObjectContext: managedContext)
        let student = NSManagedObject(entity: newStudent!, insertIntoManagedObjectContext: managedContext)
        
        // sets all values for the NSManagedObject
        student.setValue(aName, forKey: "name")
        student.setValue(aPin, forKey: "pin")
        student.setValue(classes, forKey: "classes")
        student.setValue(aPhone, forKey: "phone")
        student.setValue(anEmail, forKey: "email")
        
        
        do {
            try managedContext.save() // save context
            students.append(student)
        }
            
            
        catch {
            print("error")
        }
    }
    
    
    func fetchStudentPin(pin: String) -> Bool {
        var flag = true
         // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // creates fetch request with predicate to filter out results
        let studentFetch = NSFetchRequest(entityName: "Student")
        let pin = pin
        studentFetch.returnsObjectsAsFaults = false
        studentFetch.predicate = NSPredicate(format: "pin == %@", pin)
        
        do {
            let studentsFetched = try managedContext.executeFetchRequest(studentFetch) // executes request
            students = studentsFetched as! [NSManagedObject] // gets students and saves into array
            }
            
        catch {
            print("error")
        }
        
        if students.isEmpty { // if empty no one has that pin so return false
            flag = false
        }
        
        return flag
    }
    
    
    func fetchStudent(pin: String) -> Student {
        var student : Student!
         // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // creates fetch request with predicate to filter out results
        let studentFetch = NSFetchRequest(entityName: "Student")
        let pin = pin
        studentFetch.returnsObjectsAsFaults = false
        studentFetch.predicate = NSPredicate(format: "pin == %@", pin)
        
        do {
            let studentsFetched = try managedContext.executeFetchRequest(studentFetch) // executes request
            for stud in studentsFetched {
                student = stud as! Student // gets the student with that pin and returns it
            }
        }
            
        catch {
            print("error")
        }
        
        
        return student
    }
    
    
    func fetchStudentName(pin: String) -> String {
        
        var name : String = ""
         // get managed context reference
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        // creates fetch request with predicate to filter out results
        let studentFetch = NSFetchRequest(entityName: "Student")
        let pin = pin
        studentFetch.returnsObjectsAsFaults = false
        studentFetch.predicate = NSPredicate(format: "pin == %@", pin)
        
        do {
            
            let studentsFetched = try managedContext.executeFetchRequest(studentFetch) // executes request
            students = studentsFetched as! [NSManagedObject]
            for stud in students {
                name = stud.valueForKey("name") as! String // returns student name
            }
        }
            
        catch {
            print("error")
        }
        
        return name
    }

    
    
    
    func classesNumber() -> Int {
        return classes.count
    }
    
    func getClassInfo(index: Int) -> String {
        return classes[index]
    }
    
   
    
    
}
