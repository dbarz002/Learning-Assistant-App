//
//  professorController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/17/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class professorController: UIViewController, UINavigationControllerDelegate {
    
    var name : String = ""
    var pin : String = ""
    var classesArray : [String] = []
    let myModel = ProfessorModel.sharedInstance
    let laMod = laModel.sharedInstance
    @IBOutlet weak var nameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.delegate = self // delegate
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(animated: Bool) { // will appear method to display values in view controller
        super.viewWillAppear(animated)
        print(myModel.fetchProfessor(pin))
       // print(myModel.fetchProfessorsLearningAssistants(pin))
        nameLabel.text = name
        
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        view.endEditing(true)
        
        
    }

    
    @IBAction func addNewLearningAssistant (sender: UIButton!) {
        
    }
    
    @IBAction func deleteLearningAssistant (sender: UIButton!) {
        
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) { // method to prepare for segue
        if segue.identifier == "addLearningAssistant" {
            
            
            let detailViewController = segue.destinationViewController as! addAssistantController
            detailViewController.pin = pin // gives new controller the pin number
            
            
        }
    }
}