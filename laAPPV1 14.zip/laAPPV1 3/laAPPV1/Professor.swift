//
//  Professor.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/24/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class Professor : NSManagedObject {
    
    @NSManaged var name: String
    @NSManaged var pin: String
    @NSManaged var classes : [String]
    @NSManaged var learningAssistants : Set<LA>
    
}