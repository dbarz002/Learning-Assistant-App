//
//  createAppointmentController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/25/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit


class createAppointmentController:  UIViewController {
    @IBOutlet weak var myDatePicker: UIDatePicker!
    @IBOutlet weak var myTimePicker: UIDatePicker!
    ///@IBOutlet weak var strWeekday: UILabel!
    var dayOfWeek: String!
    var date : NSDate!
    var time : String!
    let modelLa = laModel.sharedInstance
    var hourPicked : String!
    var hourPicked2 : String!
    var passTime : String!
    var student : Student!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // set mode to date only
        myDatePicker.datePickerMode = UIDatePickerMode.Date
        // add target for the trigger update function to change the weekday when the user changes the date
        myDatePicker.addTarget(self, action: #selector(createAppointmentController.triggerUpdate(_:)), forControlEvents: UIControlEvents.ValueChanged)
        myTimePicker.addTarget(self, action: #selector(createAppointmentController.handler(_:)), forControlEvents: UIControlEvents.ValueChanged)
        
        // weekday initial value
        dayOfWeek = myDatePicker.date.weekdayName
        print(myTimePicker.date)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func triggerUpdate(sender: AnyObject) { //updates every time a datepicker is moved
        date = myDatePicker.date
        print(date)
        dayOfWeek = myDatePicker.date.weekdayName
        print(dayOfWeek)
    }
    
    func handler(sender: UIDatePicker) { // handler that returns the time in desired format for our program
        let timeFormatter = NSDateFormatter()
        timeFormatter.timeStyle = NSDateFormatterStyle.ShortStyle
        
        let strDate = timeFormatter.stringFromDate(myTimePicker.date)
        passTime = strDate
        hourPicked = strDate.stringByReplacingOccurrencesOfString(":00 ", withString: "")
        hourPicked2 = strDate.stringByReplacingOccurrencesOfString(":30 ", withString: "")
        print(hourPicked)
        print (hourPicked2)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) { // method to prepare for segue
        if segue.identifier == "selectAssistant" {
            
            var laArray : [LA] = []
            let detailViewController = segue.destinationViewController as! selectAssistantController
            let dateLAarray : [LA] = modelLa.fetchlearningAssistantDay(dayOfWeek) // fetch all la's
            for la in dateLAarray { //if la days match add to array
                let lahoursArray : [String] = la.hours
                
                for hour in lahoursArray { // if la hours match add to array
                    if hour == hourPicked || hour == hourPicked2{
                        laArray.append(la)
                    }
                    
                }
                
                
            }
           
            
            detailViewController.laArray = laArray
            detailViewController.time = passTime
            detailViewController.date = date
            detailViewController.student = student
        }
        
    }
    
}

extension NSDate {
    // returns weekday name (Sunday-Saturday) as String
    var weekdayName: String {
        let formatter = NSDateFormatter(); formatter.dateFormat = "EEEE"
        return formatter.stringFromDate(self)
    }
    
    
    


}