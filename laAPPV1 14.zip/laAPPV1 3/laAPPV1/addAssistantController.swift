//
//  addAssistantController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/19/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class addAssistantController : UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var classesTableView: UITableView!
    @IBOutlet weak var timesTableView: UITableView!
    @IBOutlet weak var daysTableView: UITableView!
    var switchTagsActive : [Int] = []
    var pin: String!
    var counter : Int = 0
    var counter1 : Int = 0
    var counter2 : Int = 0
    let professorMod = ProfessorModel.sharedInstance
    let myModel = laModel.sharedInstance
    @IBOutlet weak var picture: UIImageView!
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        // set contrains for the tables
        classesTableView.frame = CGRectMake(classesTableView.frame.origin.x, classesTableView.frame.origin.y, classesTableView.frame.size.width, classesTableView.contentSize.height)
        timesTableView.frame = CGRectMake(timesTableView.frame.origin.x, timesTableView.frame.origin.y, timesTableView.frame.size.width, timesTableView.contentSize.height)
        daysTableView.frame = CGRectMake(daysTableView.frame.origin.x, daysTableView.frame.origin.y, daysTableView.frame.size.width, daysTableView.contentSize.height)
    }
    
    override func viewDidLayoutSubviews(){
        // set contrains for the tables
        classesTableView.frame = CGRectMake(classesTableView.frame.origin.x, classesTableView.frame.origin.y, classesTableView.frame.size.width, classesTableView.contentSize.height)
        classesTableView.reloadData()
        timesTableView.frame = CGRectMake(timesTableView.frame.origin.x, timesTableView.frame.origin.y - 10, timesTableView.frame.size.width, timesTableView.contentSize.height)
        timesTableView.reloadData()
        daysTableView.frame = CGRectMake(daysTableView.frame.origin.x, daysTableView.frame.origin.y - 20, daysTableView.frame.size.width, daysTableView.contentSize.height)
        daysTableView.reloadData()
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // set delegate and data source for tables
        classesTableView.delegate = self
        classesTableView.dataSource = self
        classesTableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "reusableCell")
        
        timesTableView.delegate = self
        timesTableView.dataSource = self
        timesTableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "reusableCell1")
        
        daysTableView.delegate = self
        daysTableView.dataSource = self
        daysTableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "reusableCell2")
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(addAssistantController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    
    }
    
    func dismissKeyboard() // func to dismiss keyboard
    {
        view.endEditing(true)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int { // gtes number of sections for each table
        
       
        
        var count : Int?
        
        if tableView == self.classesTableView {
        count = myModel.classesNumber()
        }
        
        if tableView == self.timesTableView {
            count = myModel.timesNumber()
        }
        
        if tableView == self.daysTableView {
            count = myModel.daysNumber()
        }
        
        return count!
        
    }
    
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell { // populates tables
        var cell : UITableViewCell?
        let teachesClass = UISwitch(frame: CGRectZero) as UISwitch // creates uiswitch
        
        // set what table view is being used to populate correct table with coreect data.
        
        if tableView == self.classesTableView {
        cell = tableView.dequeueReusableCellWithIdentifier("reusableCell", forIndexPath: indexPath)
        //cell = UITableViewCell(style: nil, reuseIdentifier: "reusableCell")
        let classDisplay = myModel.getClassInfo(indexPath.row)
        cell!.textLabel?.text = classDisplay
        if cell?.accessoryView == nil {
        teachesClass.tag = counter
        print(teachesClass.tag) // sets tag for switch
        teachesClass.on = false // sets initial state to off
        teachesClass.addTarget(self, action: #selector(addAssistantController.switchTriggered(_:)), forControlEvents: .ValueChanged ) // calls function evreytime the switch is pressed
        cell!.accessoryView = teachesClass // adds uiswitch as accesory view
            counter = counter + 1
        }
        
        
            
        }
        
        if tableView == self.timesTableView {
            cell = tableView.dequeueReusableCellWithIdentifier("reusableCell1", forIndexPath: indexPath)
            let classDisplay = myModel.getTimesInfo(indexPath.row)
            cell!.textLabel?.text = classDisplay
            if cell?.accessoryView == nil {
            let teachesClass = UISwitch(frame: CGRectZero) as UISwitch
            teachesClass.tag = counter1
            teachesClass.on = false
            teachesClass.addTarget(self, action: #selector(addAssistantController.switchTriggered(_:)), forControlEvents: .ValueChanged )
            cell!.accessoryView = teachesClass
                counter1 = counter1 + 1
            }
        
        }
        
        if tableView == self.daysTableView {
            cell = tableView.dequeueReusableCellWithIdentifier("reusableCell2", forIndexPath: indexPath)
            let classDisplay = myModel.getDaysInfo(indexPath.row)
            cell!.textLabel?.text = classDisplay
            if cell?.accessoryView == nil {
            let teachesClass = UISwitch(frame: CGRectZero) as UISwitch
            teachesClass.tag = counter2
            teachesClass.on = false
            teachesClass.addTarget(self, action: #selector(addAssistantController.switchTriggered(_:)), forControlEvents: .ValueChanged )
            cell!.accessoryView = teachesClass
                counter2 = counter2 + 1
            }
           
        }
        
        return cell!
        
    }
    
    
    func switchTriggered(switchState: UISwitch) { // func that gets called every time a uiswitch is pressed
        
        if switchState.on {
            print("switch on")
            print(switchState.tag)
        }
        
        else {
            print("switch off")
            print(switchState.tag)
        }
    }
    
    
    @IBAction func addNewLearningAssistant() {
        // function to add new learning assistant
        
        let cells = classesTableView.visibleCells
        let cells1 = timesTableView.visibleCells
        let cells2 = daysTableView.visibleCells
        
        var classes : [String] = []
        var times : [String] = []
        var days : [String] = []
        var name : String = ""
        var email : String = ""
        var phone : String = ""
        
        if nameTextField.text != "" && emailTextField.text != "" && phoneTextField.text != "" { // validates data
            name = nameTextField.text!
            email = emailTextField.text!
            phone = phoneTextField.text!
            for cell in cells {
                
                let switchClass = cell.accessoryView as! UISwitch
                if  switchClass.on {
                    classes.append(cell.textLabel!.text! as String) // if statement that checks each switch that is turned on and returns the classes
                }
                
                
            }
            
            for cell in cells1 {
                
                let switchClass = cell.accessoryView as! UISwitch
                if  switchClass.on {
                    times.append(cell.textLabel!.text! as String)  // if statement that checks each switch that is turned on and returns the classes
                }
                
                
            }
            
            for cell in cells2 {
                
                let switchClass = cell.accessoryView as! UISwitch
                if  switchClass.on {
                    days.append(cell.textLabel!.text! as String)  // if statement that checks each switch that is turned on and returns the classes
                }
                
                
            }
            
            
            print (name)
            print(classes)
            print(phone)
            print(email)
            print(times)
            print(days)
            
            myModel.createNewLearningAssistant(name, classes: classes, hours: times, days: days, anEmail: email, aPhone: phone) // create new assistant in core data passing all corresponding fields
            
            let newLearningAssistant = myModel.fetchNewLearningAssistant(phone) // fetches assistant just created
            let professor = professorMod.fetchProfessor(pin) // fetches professor logged in currently
            
            professor.setValue(NSSet(object: newLearningAssistant), forKey: "laRel") // failed attempt at relationship
            
            do {
                try professor.managedObjectContext?.save() // saves context
            } catch {
                let saveError = error as NSError // prints error
                print(saveError)
            }
        }
            
            
        else {
            
            let alert = UIAlertController(title: "Invalid Information", message: "Please enter data in all fields.", preferredStyle: UIAlertControllerStyle.Alert) // alert if data is not valid
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            
        }
        
        
        
    }
    
    
}