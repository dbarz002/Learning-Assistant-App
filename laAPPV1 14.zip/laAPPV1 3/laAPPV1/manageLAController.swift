//
//  manageLAController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/19/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class manageLAController: UITableViewController, NSFetchedResultsControllerDelegate, UINavigationControllerDelegate {
    //var context: NSManagedObjectContext!
    var name : String = ""
    let myModel = laModel.sharedInstance
    var flag: Bool = false
    
    lazy var fetchedResultsController: NSFetchedResultsController = {
        let LAFetchRequest = NSFetchRequest(entityName: "LA")
        let SortDescriptor = NSSortDescriptor(key: "name", ascending: true)
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        LAFetchRequest.sortDescriptors = [SortDescriptor]
        let context = appDelegate.managedObjectContext
        let frc = NSFetchedResultsController(
            fetchRequest: LAFetchRequest,
            managedObjectContext: context,
            sectionNameKeyPath: "name",
            cacheName: nil)
        
        frc.delegate = self
        
        return frc
    }()
    
    func controller(
        controller: NSFetchedResultsController,
        didChangeObject anObject: AnyObject,
                        atIndexPath indexPath: NSIndexPath?,
                                    forChangeType type: NSFetchedResultsChangeType,
                                                  newIndexPath: NSIndexPath?) {
        
        switch type {
        case NSFetchedResultsChangeType.Insert:
            // Note that for Insert, we insert a row at the __newIndexPath__
            if let insertIndexPath = newIndexPath {
                self.tableView.insertRowsAtIndexPaths([insertIndexPath], withRowAnimation: UITableViewRowAnimation.Fade)
            }
        case NSFetchedResultsChangeType.Delete:
            // Note that for Delete, we delete the row at __indexPath__
            if let deleteIndexPath = indexPath {
                self.tableView.deleteRowsAtIndexPaths([deleteIndexPath], withRowAnimation: UITableViewRowAnimation.Fade)
            }
        case NSFetchedResultsChangeType.Update:
            if let updateIndexPath = indexPath {
                // Note that for Update, we update the row at __indexPath__
                let cell = self.tableView.cellForRowAtIndexPath(updateIndexPath)
                let learningAssistant = fetchedResultsController.objectAtIndexPath(indexPath!) as! LA
                
                cell?.textLabel?.text = learningAssistant.name
                
            }
        case NSFetchedResultsChangeType.Move:
            // Note that for Move, we delete the row at __indexPath__
            if let deleteIndexPath = indexPath {
                self.tableView.deleteRowsAtIndexPaths([deleteIndexPath], withRowAnimation: UITableViewRowAnimation.Fade)
            }
            
            // Note that for Move, we insert a row at the __newIndexPath__
            if let insertIndexPath = newIndexPath {
                self.tableView.insertRowsAtIndexPaths([insertIndexPath], withRowAnimation: UITableViewRowAnimation.Fade)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        do {
            try fetchedResultsController.performFetch()
        } catch {
            print("An error occurred")
        }
        navigationController?.delegate = self // delegate
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(animated: Bool) { // will appear method to display values in view controller
        super.viewWillAppear(animated)
        
        //tableView.reloadData()
        
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        
        view.endEditing(true)
        
        
    }
    
    func controllerWillChangeContent(controller: NSFetchedResultsController) {
        self.tableView.beginUpdates()
    }
    
    func controllerDidChangeContent(controller: NSFetchedResultsController) {
        tableView.reloadData()
        self.tableView.endUpdates()
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
    if let sections = fetchedResultsController.sections {
        
        return sections.count
        
        }
        
    return 0
        
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // la list size
        
        
        if let sections = fetchedResultsController.sections {
            let currentSection = sections[section]
            return currentSection.numberOfObjects
        }
      
      return 0
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCellWithIdentifier("reusableCell", forIndexPath: indexPath)
        let learningAssistant = fetchedResultsController.objectAtIndexPath(indexPath) as! LA
        
        cell.textLabel?.text = learningAssistant.name
        
        
        return cell
    }
    
   
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) { // method to delete row
        
        switch editingStyle {
        case .Delete:
            
            let appDel:AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            let context:NSManagedObjectContext = appDel.managedObjectContext
            
            let index = indexPath.section
            
            var object = fetchedResultsController.fetchedObjects as! [NSManagedObject]
            context.deleteObject(object[index])
            
         
            let _ : NSError! = nil
            do {
                try context.save()
            } catch {
                print("error : \(error)")
            }
            
           self.tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        default:
            return
        }
    }
    }
