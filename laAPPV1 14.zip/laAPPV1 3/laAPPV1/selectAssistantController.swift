//
//  selectAssistantController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/26/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit


class selectAssistantController:  UIViewController, UITableViewDelegate, UITableViewDataSource  {
    var laArray : [LA]!
     @IBOutlet weak var assistantsTableView: UITableView!
    var time : String!
    var date : NSDate!
    var student : Student!
    override func viewDidLoad() {
        super.viewDidLoad()
        //sets source and delegate for table
        assistantsTableView.delegate = self
        assistantsTableView.dataSource = self
        
       print(laArray)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int { // sets number of rows in section
        
        return laArray.count
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell { // populates cells
        let cell = tableView.dequeueReusableCellWithIdentifier("reusableCell", forIndexPath: indexPath)
        let laName = laArray[indexPath.row]
        cell.textLabel?.text = laName.name
        return cell
        
    }
    
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) { // method to prepare for segue
        if segue.identifier == "confirmAppointment" {
            if let row = assistantsTableView.indexPathForSelectedRow?.row {
            let la : LA = laArray[row]
            let name : String = la.name!
            let detailViewController = segue.destinationViewController as! confirmAppointmenController
            detailViewController.day = date
            detailViewController.time = time
            detailViewController.nameLA = name
            detailViewController.learningAssistant = la
            detailViewController.student = student
            }
        }
        
    }

}
