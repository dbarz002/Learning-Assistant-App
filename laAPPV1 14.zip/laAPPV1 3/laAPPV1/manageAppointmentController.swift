//
//  manageAppointmentController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/25/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class manageAppointmentController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate{
    
    @IBOutlet weak var appointmentsTableView: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    var searchActive : Bool = false
    var arrayAppointments : [Appointment]!
    var filtered:[String] = []
    var time : String!
    var date : NSDate!
    var student : Student!
    var laNames:[String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        // sets source and delegate for table
        appointmentsTableView.delegate = self
        appointmentsTableView.dataSource = self
        searchBar.delegate = self
        print(arrayAppointments)
        var counter = 0;
        // creates array with la names to be used for filtering
        for appointment in arrayAppointments{
            laNames.append(appointment.la as! String)
            counter += 1;
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated
        
    }
    
    func searchBarTextDidBeginEditing(searchBar: UISearchBar) { // turns flag on when something is typed on search bar
        searchActive = true;
    }
    
    func searchBarTextDidEndEditing(searchBar: UISearchBar) { // turns flag off when text editing ends
        searchActive = false;
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) { // when the cancel button is clicked the flag is false
        searchActive = false;
    }
    
    func searchBarSearchButtonClicked(searchBar: UISearchBar) { // when the search bar is clicked flag is on
        searchActive = false;
    }
    
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        
        // creates filtered list to be loaded in table view
        filtered = laNames.filter({ (text) -> Bool in
            let tmp: NSString = text
            let range = tmp.rangeOfString(searchText, options: NSStringCompareOptions.CaseInsensitiveSearch)
            return range.location != NSNotFound
        })
        if(filtered.count == 0){ // if there is nothing on the array then populate with regular data
            searchActive = false;
        } else { // else use filtered data
            searchActive = true;
        }
        self.appointmentsTableView.reloadData() // reload view
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int { // return number of sections
        if(searchActive) { // if flag is true use size of filtered array
            return filtered.count
        }
        return arrayAppointments.count //else return regular size
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell { // populates cells
        let cell = tableView.dequeueReusableCellWithIdentifier("reusableCell", forIndexPath: indexPath)
        
        if(searchActive){ // if active poulate cells with filtered array
            cell.textLabel?.text = "Appointment with: " + filtered[indexPath.row]
        } else { // populate regular data
            let appointment = arrayAppointments[indexPath.row] // populate each row with a new appointment
            let dateFormatter = NSDateFormatter() // formats date
            dateFormatter.dateFormat = "MM/dd/yy"
            let dateString = dateFormatter.stringFromDate(appointment.date!)
            let celltext : String = "Appointment on: " + dateString + " with " + (appointment.la! as! String) // prints label
            cell.textLabel?.text = celltext
        }
        
        return cell
        
    }
    
    
     func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) { // method to delete row
     
        
        
        
    }
    
            

    
}