//
//  adminController2.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/18/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
//
//  ProfessorController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/17/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class adminController2 : UIViewController, UITableViewDelegate, UITableViewDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var pinTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var phoneTextField: UITextField!
    @IBOutlet weak var classesTableView: UITableView!
    @IBOutlet weak var picture: UIImageView!
    
    var switchTagsActive : [Int] = []
    
    let myModel = studentModel.sharedInstance
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        //sets data source and delegate
        classesTableView.delegate = self
        classesTableView.dataSource = self
        
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(addAssistantController.dismissKeyboard)) // tap recognizer to dimiss keyboard
        view.addGestureRecognizer(tap)
        
    }
    
    func dismissKeyboard() // function to dismiss keyboard
    {
        view.endEditing(true)
    }
    
    @IBAction func pressedCamera(sender: AnyObject) {
        
        let imagePicker = UIImagePickerController()
        
        if UIImagePickerController.isSourceTypeAvailable(.Camera) {
            imagePicker.sourceType = .Camera
            imagePicker.allowsEditing = true
            imagePicker.cameraCaptureMode = .Photo // or .Video
            imagePicker.modalPresentationStyle = .FullScreen
        }
        else {
            imagePicker.sourceType = .PhotoLibrary
        }
        
        imagePicker.delegate = self
        
        presentViewController(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        picture.image = image
        
        dismissViewControllerAnimated(true, completion: nil)
        
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return myModel.classesNumber()
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell { // populates table cells
        let cell = tableView.dequeueReusableCellWithIdentifier("reusableCell", forIndexPath: indexPath)
        let classDisplay = myModel.getClassInfo(indexPath.row) // gets class info to display from shared instance
        cell.textLabel?.text = classDisplay
        let teachesClass = UISwitch(frame: CGRectZero) as UISwitch // creates uiswitch
        teachesClass.tag = indexPath.row // sets tag for switch
        teachesClass.on = false // sets initial state to off
        teachesClass.addTarget(self, action: #selector(adminController2.switchTriggered(_:)), forControlEvents: .ValueChanged )// calls function evreytime the switch is pressed
        cell.accessoryView = teachesClass // adds uiswitch as accesory view
        
        return cell
        
    }
    
    func switchTriggered(switchState: UISwitch) { // func that gets called every time a uiswitch is pressed
        
        if switchState.on {
            print("switch on")
            print(switchState.tag)
        }
            
        else {
            print("switch off")
            print(switchState.tag)
        }
    }
    
    
    @IBAction func addNewStudent() {
        // function to add new student
        
        let cells = classesTableView.visibleCells
        var classes : [String] = []
        var name : String = ""
        var pin : String = ""
        var email : String = ""
        var phone : String = ""
        
        if nameTextField.text != "" && pinTextField.text != "" && emailTextField.text != "" && phoneTextField.text != "" { // validates data
            name = nameTextField.text!
            pin = pinTextField.text!
            email = emailTextField.text!
            phone = phoneTextField.text!
            for cell in cells {
                
                let switchClass = cell.accessoryView as! UISwitch
                if  switchClass.on { // if statement that checks each switch that is turned on and returns the classes
                    classes.append(cell.textLabel!.text! as String)
                }
                
                
            }
            
            myModel.createNewStudent(name, aPin: pin, classes: classes, anEmail: email, aPhone: phone) // creates new student
            print (name)
            print (pin)
            print(classes)
            print(phone)
            print(email)
        }
            
            
        else {
            
            let alert = UIAlertController(title: "Invalid Information", message: "Please enter data in all fields.", preferredStyle: UIAlertControllerStyle.Alert) // alert if data is not valid
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
            
        }
        
        
        
    }
    
    
}