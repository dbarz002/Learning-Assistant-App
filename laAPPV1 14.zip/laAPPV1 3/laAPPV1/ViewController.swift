//
//  ViewController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/17/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import UIKit

class loginController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

