//
//  loginController.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/17/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit


class loginController: UIViewController {
    
    @IBOutlet weak var indexOne: UILabel!
    @IBOutlet weak var indexTwo: UILabel!
    @IBOutlet weak var indexThree: UILabel!
    @IBOutlet weak var indexFour: UILabel!
    @IBOutlet weak var indexFive: UILabel!
    @IBOutlet weak var indexSix: UILabel!
    @IBOutlet weak var indexSeven: UILabel!
    @IBOutlet weak var numberOne: UIButton!
    @IBOutlet weak var numberTwo: UIButton!
    @IBOutlet weak var numberThree: UIButton!
    @IBOutlet weak var numberFour: UIButton!
    @IBOutlet weak var numberFive: UIButton!
    @IBOutlet weak var numberSix: UIButton!
    @IBOutlet weak var numberSeven: UIButton!
    @IBOutlet weak var numberEight: UIButton!
    @IBOutlet weak var numberNine: UIButton!
    @IBOutlet weak var numberZero: UIButton!
    @IBOutlet weak var deleteButton: UIButton!
    var counter : Int = 0
    var pinNumber: String!
    var pinComplete: Bool = false
    let myModel = ProfessorModel.sharedInstance
    let studentInstance = studentModel.sharedInstance
    var name : String = ""
    var classesArray : [String] = []
    var student : Student!
    
    @IBAction func changeLabel(sender : AnyObject) { // method that changes the labels
        
        
        if counter == 0 {
            indexOne.text = String(sender.tag)
            pinNumber = indexOne.text
        }
        
        if counter == 1 {
            indexTwo.text = String(sender.tag);
            pinNumber = pinNumber + String(sender.tag)
        }
        
        if counter == 2 {
            indexThree.text = String(sender.tag);
            pinNumber = pinNumber + String(sender.tag)
        }
        
        if counter == 3 {
            indexFour.text = String(sender.tag);
            pinNumber = pinNumber + String(sender.tag)
        }
        
        if counter == 4 {
            indexFive.text = String(sender.tag);
            pinNumber = pinNumber + String(sender.tag)
        }
        
        if counter == 5 {
            indexSix.text = String(sender.tag);
            pinNumber = pinNumber + String(sender.tag)
        }
        
        if counter == 6 {
            
            indexSeven.text = String(sender.tag)
            pinNumber = pinNumber + String(sender.tag)
            pinComplete = true
            
            if myModel.fetchProfessorsPin(pinNumber) { // checks if pin number is right
            name =  myModel.fetchProfessorsName(pinNumber) // fetches professors name
            classesArray = myModel.fetchProfessorsClasses(pinNumber) // gets classes from professor
              performSegueWithIdentifier("professorPinValid", sender: self) // calls professor view
                
                
            }
                
            else if studentInstance.fetchStudentPin(pinNumber) { // checks if pin number is right
            name =  studentInstance.fetchStudentName(pinNumber) // fetches student name
                student = studentInstance.fetchStudent(pinNumber) // gets student obbject
              performSegueWithIdentifier("studentPinValid", sender: self) // calls student view
                
            }
                
            else { // else throws alert view
                let alert = UIAlertController(title: "Wrong Pin", message: "The pin entered is not associated to any student or professor, please enter a vaild pin.", preferredStyle: UIAlertControllerStyle.Alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
                self.presentViewController(alert, animated: true, completion: nil)
            }
        }
        
        print(pinNumber)
        print (pinComplete)
        counter = counter + 1
        
        if (pinComplete) { // checks if pin was completed
            pinNumber = "";
            counter = 0;
            indexOne.text = "0"
            indexTwo.text = "0"
            indexThree.text = "0"
            indexFour.text = "0"
            indexFive.text = "0"
            indexSix.text = "0"
            indexSeven.text = "0"
            pinComplete = false;
        }
    }
    
    @IBAction func deleteNumber (sender : AnyObject) { // function to delete a number in pin
        
        counter = counter - 1
        
        
        if counter <= 0 {
            indexOne.text = "0"
            counter = 0
        }
            
        else {
            
            
            if counter == 1 {
                indexTwo.text = "0"
                pinNumber.removeAtIndex(pinNumber.endIndex.predecessor())
            }
            
            if counter == 2 {
                indexThree.text = "0"
                pinNumber.removeAtIndex(pinNumber.endIndex.predecessor())
            }
            
            if counter == 3 {
                indexFour.text = "0"
                pinNumber.removeAtIndex(pinNumber.endIndex.predecessor())
            }
            
            if counter == 4 {
                indexFive.text = "0"
                pinNumber.removeAtIndex(pinNumber.endIndex.predecessor())
            }
            if counter == 5 {
                indexSix.text = "0"
                pinNumber.removeAtIndex(pinNumber.endIndex.predecessor())
            }
            
            
            print(pinNumber)
            print (pinComplete)
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       // print(myModel.fetchProfessorsName())
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(true)
        
        
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) { // method to prepare for segue
        if segue.identifier == "professorPinValid" {
            
            
            let detailViewController = segue.destinationViewController as! professorController
            detailViewController.name = name
            detailViewController.classesArray = classesArray
            detailViewController.pin = pinNumber
        }
        
        if segue.identifier == "studentPinValid" {
            
            
            let detailViewController = segue.destinationViewController as! studentController
            detailViewController.name = name
            detailViewController.student = student
            
        }
    }
  

    
}