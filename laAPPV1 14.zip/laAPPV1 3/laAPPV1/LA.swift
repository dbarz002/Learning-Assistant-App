//
//  LA.swift
//  laAPPV1
//
//  Created by david a barzallo on 4/24/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class LA : NSManagedObject {
    
    @NSManaged var name: String
    @NSManaged var email: String
    @NSManaged var phone: String
    @NSManaged var days : [String]
    @NSManaged var classes : [String]
    @NSManaged var hours : [String]
    @NSManaged var prof: Professor


    
}